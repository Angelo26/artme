<?php
    require 'dbh.inc.php';

    session_start();
    if(!isset($_SESSION['u_uid'])) {
        header("location:index.php");
    }
        $aid = $_GET['id'];
        $sql = "SELECT * FROM artists WHERE id='$aid';";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);

        $first = $row["fname"];
        $last = $row["lname"];
        $email = $row["email"];
        $hashedPwd = $row["pwd"];
		$address = $row["aaddress"];
		$skills = $row["skills"];
		$skill1 = $row["skill1"];
		$skill2 = $row["skill2"];
        $contact = $row["contact"];
        $destinationfile = $row["img"];
        
		$sql = "INSERT INTO realartists(artist_id, artist_first, artist_last, artist_email, artist_pwd, artist_address, artist_skills, artist_skill1, artist_skill2, artist_contact, artist_img, artist_status) VALUES ('$aid', '$first', '$last', '$email', '$hashedPwd', '$address', '$skills', '$skill1', '$skill2', '$contact', '$destinationfile', 'active');";
        if(mysqli_query($conn, $sql)){
            
            $sql2 = "DELETE from artists where id = '$aid'";
            $result2 = mysqli_query($conn, $sql2);
            mysqli_close($conn);
            $tablename = $first.$aid;
            $sql3= "CREATE TABLE $tablename (
                id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(255),
                contact VARCHAR(255),
                usermessage varchar(255)
                )";
            if (mysqli_query($conn2, $sql3)) {

                $sql4 = "CREATE TABLE $tablename (
                    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                    client VARCHAR(255)
                    )";
                
                if (mysqli_query($conn3, $sql4)) {
                    header("Location: ../verifyartists.php?Verified successfully");
                    exit();
                }
            }
        }
    					
?>