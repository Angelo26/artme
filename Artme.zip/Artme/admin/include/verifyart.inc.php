<?php
    require 'dbh.inc.php';

    session_start();
    if(!isset($_SESSION['u_uid'])) {
        header("location:index.php");
    }
        $aid = $_GET['id'];
        $sql = "SELECT * FROM arts WHERE id='$aid';";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);

        $name = $row["aname"];
        $style = $row["astyle"];
        $artist = $row["artist"];
        $price = $row["price"];
		$destinationfile = $row['picture'];
		

		$sql = "INSERT INTO artworks (art_name, art_style, artist, price, astatus, picture) VALUES ('$name', '$style', '$artist', '$price', 'Available','$destinationfile');";
		if(mysqli_query($conn, $sql)){
            $sql2 = "DELETE from arts where id = '$aid'";
            $result2 = mysqli_query($conn, $sql2);
            mysqli_close($conn);
			header("Location: ../verifyarts.php?Successfully added");
			exit();
		}
		
?>