<?php

	if(isset($_POST['submit'])) {
		session_start();

		require 'include/dbh.inc.php';

		$file = $_FILES['image'];
		$filename = $file['name'];
        
        if($filename=="") {
            header("Location: adminchgdesc.php");
            exit();
        }

        else {

            $fileerror = $file['error'];
            $filetmp = $file['tmp_name'];
            
            $fileext = explode('.',$filename);
            
            $filecheck = strtolower(end($fileext));
            
            $allowed = array('png', 'jpg', 'jpeg');

            if (in_array($filecheck,$allowed)) {
                
                $destinationfile='imgs/'.$filename;
				move_uploaded_file($filetmp, '../imgs/'.$filename);
		
                $uid = $_GET['id'];
                $sql = "UPDATE changedesc SET img='$destinationfile' WHERE id='$uid';";
                if(mysqli_query($conn, $sql)){
                    header("Location: adminchgdesc.php?id=$uid");
                    exit();
                }
            }
                $
		    else {
                header("Location: adminchgdesc.php?couldn't_upload_image");
                exit();
           }
        }
    }
?>