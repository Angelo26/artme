$(document).ready(function () {
    $(".art").imagezoomsl({
        zoomrange: [3, 3]
    });
});
